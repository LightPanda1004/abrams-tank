"use strict";

const ROOM_CAPACITY = 32;
const MAX_WORLD_COORDINATE = 100;
const MOVE_SPEED = 8;
const TURN_SPEED = 75;
const PROJECTILE_SPEED = 42;
const PROJECTILE_DAMAGE = 25;
const PROJECTILE_RANGE = 80;
const FIRE_COOLDOWN_MS = 1800;
const RESPAWN_DELAY_MS = 3500;

function clamp(value, minimum, maximum) {
    return Math.max(minimum, Math.min(maximum, value));
}

class GameRoom {
    constructor(roomId, capacity = ROOM_CAPACITY) {
        if (typeof roomId !== "string" || !roomId) {
            throw new TypeError("A room id is required.");
        }
        if (!Number.isInteger(capacity) || capacity < 2 ||
            capacity > ROOM_CAPACITY) {
            throw new RangeError(`Room capacity must be between 2 and ${ROOM_CAPACITY}.`);
        }

        this.roomId = roomId;
        this.capacity = capacity;
        this.players = new Map();
        this.projectiles = [];
        this.pendingEvents = [];
        this.nextProjectileId = 1;
    }

    addPlayer({ userId, playerName, team }) {
        if (typeof userId !== "string" || !/^[1-9]\d{0,18}$/.test(userId) ||
            typeof playerName !== "string" || !playerName ||
            (team !== 1 && team !== 2)) {
            throw new TypeError("Player identity, name, or team is invalid.");
        }
        if (this.players.has(userId)) {
            throw new Error("This player is already connected to the room.");
        }
        if (this.players.size >= this.capacity) {
            throw new Error("The room is full.");
        }

        const teamPlayers = [...this.players.values()]
            .filter(player => player.team === team).length;
        const spawnX = team === 1 ? -24 : 24;
        const player = {
            userId,
            playerName,
            team,
            x: spawnX,
            z: (teamPlayers - (this.capacity / 4)) * 6,
            heading: team === 1 ? 90 : -90,
            throttle: 0,
            steering: 0,
            health: 100,
            kills: 0,
            deaths: 0,
            alive: true,
            respawnAt: 0,
            lastFireAt: 0,
            previousFire: false
        };
        this.players.set(userId, player);
        this.pendingEvents.push({
            type: "playerJoined",
            userId,
            playerName,
            team
        });
        return this.snapshot();
    }

    removePlayer(userId) {
        const player = this.players.get(userId);
        if (!player) {
            return false;
        }
        this.players.delete(userId);
        this.projectiles = this.projectiles.filter(
            projectile => projectile.ownerId !== userId
        );
        this.pendingEvents.push({ type: "playerLeft", userId });
        return true;
    }

    setInput(userId, input, now = Date.now()) {
        const player = this.players.get(userId);
        if (!player || !input || typeof input !== "object" ||
            Array.isArray(input) ||
            typeof input.throttle !== "number" ||
            typeof input.steering !== "number" ||
            typeof input.fire !== "boolean" ||
            !Number.isFinite(input.throttle) ||
            !Number.isFinite(input.steering)) {
            return false;
        }

        player.throttle = player.alive
            ? clamp(input.throttle, -1, 1)
            : 0;
        player.steering = player.alive
            ? clamp(input.steering, -1, 1)
            : 0;

        if (player.alive && input.fire && !player.previousFire &&
            now - player.lastFireAt >= FIRE_COOLDOWN_MS) {
            player.lastFireAt = now;
            this.projectiles.push(this.createProjectile(player, now));
        }
        player.previousFire = input.fire;
        return true;
    }

    tick(deltaSeconds, now = Date.now()) {
        const delta = clamp(deltaSeconds, 0, 0.1);
        for (const player of this.players.values()) {
            if (!player.alive) {
                if (now >= player.respawnAt) {
                    this.respawn(player);
                }
                continue;
            }

            player.heading = ((player.heading +
                player.steering * TURN_SPEED * delta) % 360 + 360) % 360;
            const radians = player.heading * Math.PI / 180;
            player.x = clamp(
                player.x + Math.sin(radians) * player.throttle *
                    MOVE_SPEED * delta,
                -MAX_WORLD_COORDINATE,
                MAX_WORLD_COORDINATE
            );
            player.z = clamp(
                player.z + Math.cos(radians) * player.throttle *
                    MOVE_SPEED * delta,
                -MAX_WORLD_COORDINATE,
                MAX_WORLD_COORDINATE
            );
        }

        this.advanceProjectiles(delta, now);
        const events = this.pendingEvents;
        this.pendingEvents = [];
        return {
            type: "state",
            roomId: this.roomId,
            players: [...this.players.values()].map(player => ({
                userId: player.userId,
                playerName: player.playerName,
                team: player.team,
                x: round(player.x),
                z: round(player.z),
                heading: round(player.heading),
                health: player.health,
                kills: player.kills,
                deaths: player.deaths,
                alive: player.alive
            })),
            projectiles: this.projectiles.map(projectile => ({
                id: projectile.id,
                ownerId: projectile.ownerId,
                x: round(projectile.x),
                z: round(projectile.z),
                heading: round(projectile.heading)
            })),
            events
        };
    }

    snapshot() {
        return {
            type: "state",
            roomId: this.roomId,
            players: [...this.players.values()].map(player => ({
                userId: player.userId,
                playerName: player.playerName,
                team: player.team,
                x: round(player.x),
                z: round(player.z),
                heading: round(player.heading),
                health: player.health,
                kills: player.kills,
                deaths: player.deaths,
                alive: player.alive
            })),
            projectiles: [],
            events: []
        };
    }

    createProjectile(player, now) {
        const radians = player.heading * Math.PI / 180;
        return {
            id: this.nextProjectileId++,
            ownerId: player.userId,
            team: player.team,
            x: player.x + Math.sin(radians) * 2.5,
            z: player.z + Math.cos(radians) * 2.5,
            heading: player.heading,
            distance: 0,
            createdAt: now
        };
    }

    advanceProjectiles(delta, now) {
        const remaining = [];
        for (const projectile of this.projectiles) {
            const radians = projectile.heading * Math.PI / 180;
            const distance = PROJECTILE_SPEED * delta;
            projectile.x += Math.sin(radians) * distance;
            projectile.z += Math.cos(radians) * distance;
            projectile.distance += distance;

            const target = [...this.players.values()].find(player =>
                player.alive &&
                player.team !== projectile.team &&
                squaredDistance(player, projectile) <= 2.5 * 2.5
            );
            if (target) {
                target.health = Math.max(0, target.health - PROJECTILE_DAMAGE);
                this.pendingEvents.push({
                    type: "playerHit",
                    userId: target.userId,
                    health: target.health,
                    projectileId: projectile.id
                });
                if (target.health === 0) {
                    target.alive = false;
                    target.deaths++;
                    target.respawnAt = now + RESPAWN_DELAY_MS;
                    const attacker = this.players.get(projectile.ownerId);
                    if (attacker) {
                        attacker.kills++;
                    }
                    this.pendingEvents.push({
                        type: "playerDestroyed",
                        userId: target.userId,
                        attackerId: attacker ? attacker.userId : ""
                    });
                }
                continue;
            }

            if (projectile.distance < PROJECTILE_RANGE) {
                remaining.push(projectile);
            }
        }
        this.projectiles = remaining;
    }

    respawn(player) {
        player.alive = true;
        player.health = 100;
        player.throttle = 0;
        player.steering = 0;
        player.x = player.team === 1 ? -24 : 24;
        player.z = 0;
        player.heading = player.team === 1 ? 90 : -90;
        player.respawnAt = 0;
        this.pendingEvents.push({
            type: "playerRespawned",
            userId: player.userId
        });
    }
}

function squaredDistance(left, right) {
    const dx = left.x - right.x;
    const dz = left.z - right.z;
    return dx * dx + dz * dz;
}

function round(value) {
    return Math.round(value * 100) / 100;
}

module.exports = {
    GameRoom,
    ROOM_CAPACITY
};
